using Logica_Fabrica;

namespace Pruebas_Unitarias
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [DataRow(primerDato: 0, segundoDato: 1)]
        [DataRow(primerDato: 0, segundoDato: 1)]
        [DataRow(primerDato: 0, segundoDato: 1)]
        [DataRow(primerDato: 0, segundoDato: 1)]
        [DataRow(primerDato: 0, segundoDato: 1)]
        [DataRow(primerDato: 0, segundoDato: 1)]
        public void Given_When_Then()
        {
            //Ar


            //Ac


            //As
        }
    }
}